/* =============================================
   UGOM TV — settings.js
   Place in: assets/js/settings.js
   ============================================= */

(function () {
    "use strict";

    const THEME_KEY  = "ugomtv_theme";
    const TOGGLE_KEY = "ugomtv_toggles";

    /* ── Theme ── */

    function applyTheme(theme) {
        document.documentElement.setAttribute("data-theme", theme);
    }

    function setActiveBtn(theme) {
        document.querySelectorAll(".theme-btn").forEach(function (btn) {
            btn.classList.toggle("active", btn.dataset.theme === theme);
        });
    }

    function selectTheme(theme) {
        localStorage.setItem(THEME_KEY, theme);
        applyTheme(theme);
        setActiveBtn(theme);
    }

    function initTheme() {
        var saved = localStorage.getItem(THEME_KEY) || "system";
        applyTheme(saved);
        setActiveBtn(saved);
    }

    document.querySelectorAll(".theme-btn").forEach(function (btn) {
        btn.addEventListener("click", function () {
            selectTheme(btn.dataset.theme);
        });
    });

    /* ── Toggles ── */

    function loadToggles() {
        try {
            var raw = localStorage.getItem(TOGGLE_KEY);
            return raw ? JSON.parse(raw) : {};
        } catch (e) {
            return {};
        }
    }

    function saveToggles(states) {
        localStorage.setItem(TOGGLE_KEY, JSON.stringify(states));
    }

    function initToggles() {
        var checkboxes = document.querySelectorAll(".toggle-switch input[type='checkbox']");
        var saved = loadToggles();

        checkboxes.forEach(function (cb, i) {
            if (Object.prototype.hasOwnProperty.call(saved, i)) {
                cb.checked = saved[i];
            }

            cb.addEventListener("change", function () {
                var states = {};
                checkboxes.forEach(function (c, idx) { states[idx] = c.checked; });
                saveToggles(states);
            });
        });
    }


    /* ── Init ── */

    initTheme();
    initToggles();

})();
