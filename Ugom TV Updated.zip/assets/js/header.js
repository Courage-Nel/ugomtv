class SiteHeader extends HTMLElement {

  connectedCallback() {
    this.render();
    this.afterRender();
  }

  // Build header UI
  render() {
    this.innerHTML = `
      <header>

        <div class="logo">
          <a href="/">
            <img src="assets/images/ugomtv.png" alt="Ugom TV Logo"> ™
          </a>
        </div>

        <div class="header-buttons">

          <a href="/profile/" class="user-avatar">
            <img src="https://via.placeholder.com/40" alt="Profile">
          </a>

          <button class="search-btn">
            <i data-feather="search"></i>
          </button>

          <button class="hamburger-btn" id="menuBtn">
            <i data-feather="menu"></i>
          </button>

        </div>

        <nav>
          <ul>
            <li><a href="/"><i data-feather="home"></i> HOME</a></li>
            <li><a href="/news/"><i data-feather="globe"></i> NEWS</a></li>
            <li><a href="/media/"><i data-feather="video"></i> MEDIA</a></li>
            <li><a href="/music/"><i data-feather="music"></i> MUSIC</a></li>
            <li><a href="/about/"><i data-feather="info"></i> ABOUT</a></li>
            <li><a href="/contact/"><i data-feather="mail"></i> CONTACT</a></li>
            <li><a href="/faqs/"><i data-feather="help-circle"></i> FAQS</a></li>
            <li><a href="/settings/"><i data-feather="settings"></i> SETTINGS</a></li>
          </ul>
        </nav>

      </header>
    `;
  }

  afterRender() {
    this.initMenu();
    this.initFeather();
  }

  initMenu() {
    const btn = this.querySelector("#menuBtn");
    const nav = this.querySelector("nav");

    btn.addEventListener("click", () => {
      nav.classList.toggle("open");
      document.body.style.overflow = nav.classList.contains("open") ? "hidden" : "auto";
    });
  }

  initFeather() {
    if (window.feather) {
      requestAnimationFrame(() => feather.replace());
    }
  }
}

customElements.define("site-header", SiteHeader);