const menuBtn = document.getElementById("menuBtn");
const nav = document.querySelector("nav");

menuBtn.addEventListener("click", () => {
  // toggle menu open state
  nav.classList.toggle("open");

  // lock body scroll when open, restore when closed
  if (nav.classList.contains("open")) {
    document.body.style.overflow = "hidden";
  } else {
    document.body.style.overflow = "";
  }
});

// Clock function
function updateClock() {
    const now = new Date();

    const days = ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"];
    const months = ["Jan", "Feb", "Mar", "Apr", "May", "Jun",
                    "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];

    const dayName = days[now.getDay()];
    const monthName = months[now.getMonth()];
    const day = now.getDate();
    const year = now.getFullYear();

    let hour = now.getHours();
    const minute = now.getMinutes().toString().padStart(2, '0');
    const second = now.getSeconds().toString().padStart(2, '0');
    const ampm = hour >= 12 ? 'PM' : 'AM';
    hour = hour % 12 || 12;

    const formatted = `${dayName}, ${monthName} ${day}, ${year} - ${hour}:${minute}:${second} ${ampm}`;
    
    const clockElement = document.getElementById('clock');
    if (clockElement) {
        clockElement.textContent = formatted;
    }
}

    // Start clock
    updateClock();
    setInterval(updateClock, 1000);

    

