class SiteFooter extends HTMLElement {
  connectedCallback() {
    this.render();
  }

  render() {
    const year = new Date().getFullYear();

    this.innerHTML = `
      <footer>
        <p>Ugom TV. All rights reserved.</p>

          <a href="mailto:ugomtv2021@gmail.com">EMAIL</a> |
          <a href="assets/pages/privacy.html">PRIVACY POLICY</a> |
          <a href="assets/pages/terms.html">TERMS AND CONDITIONS</a> |
          <a href="assets/pages/help.html">HELP</a> |
          <a href="about/">ABOUT US</a>

        <p>Copyright © <span>${year}</span></p>
      </footer>
    `;
  }
}

customElements.define("site-footer", SiteFooter);