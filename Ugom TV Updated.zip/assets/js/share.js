class ShareModal extends HTMLElement {

  connectedCallback() {

    this.innerHTML = `
    
      <button class="share-btn">Share</button>

      <div class="share-modal">

        <div class="modal-content">

          <div class="modal-header">
            <h3>Share</h3>
            <span class="close-btn">&times;</span>
          </div>

          <div class="modal-body">

            <img class="previewImg" src="" alt="Preview">

            <strong class="shareTitle"></strong>

            <p class="shareDesc"></p>

            <input type="text" class="shareLink" readonly>

            <button class="copyBtn">Copy Link</button>

            <div class="socials">

              <button class="whatsappBtn">
                <img src="assets/svg/whatsapp.svg">
              </button>

              <button class="facebookBtn">
                <img src="assets/svg/facebook.svg">
              </button>

              <button class="twitterBtn">
                <img src="assets/svg/x.svg">
              </button>

            </div>

          </div>

        </div>

      </div>
    `;

    const shareBtn = this.querySelector(".share-btn");
    const modal = this.querySelector(".share-modal");
    const closeBtn = this.querySelector(".close-btn");

    const titleEl = this.querySelector(".shareTitle");
    const descEl = this.querySelector(".shareDesc");
    const imgEl = this.querySelector(".previewImg");
    const linkEl = this.querySelector(".shareLink");

    const copyBtn = this.querySelector(".copyBtn");

    // OPEN MODAL
    shareBtn.onclick = () => {

      const url = window.location.href;

      const ogTitle = document.querySelector('meta[property="og:title"]')?.content;

      const ogDesc = document.querySelector('meta[property="og:description"]')?.content;

      const ogImage = document.querySelector('meta[property="og:image"]')?.content;

      titleEl.innerText = ogTitle || document.title;

      descEl.innerText = ogDesc || "";

      imgEl.src = ogImage || "";

      linkEl.value = url;

      modal.style.display = "flex";
    };

    // CLOSE MODAL
    closeBtn.onclick = () => {
      modal.style.display = "none";
    };

    // CLOSE OUTSIDE
    window.addEventListener("click", (e) => {
      if (e.target === modal) {
        modal.style.display = "none";
      }
    });

    // COPY LINK
    copyBtn.onclick = () => {

      navigator.clipboard.writeText(linkEl.value);

      copyBtn.innerText = "Copied!";

      setTimeout(() => {
        copyBtn.innerText = "Copy Link";
      }, 2000);
    };

    // WHATSAPP
    this.querySelector(".whatsappBtn").onclick = () => {

      const url = encodeURIComponent(window.location.href);

      window.open(`https://wa.me/?text=${url}`);
    };

    // FACEBOOK
    this.querySelector(".facebookBtn").onclick = () => {

      const url = encodeURIComponent(window.location.href);

      window.open(
        `https://www.facebook.com/sharer/sharer.php?u=${url}`
      );
    };

    // TWITTER
    this.querySelector(".twitterBtn").onclick = () => {

      const url = encodeURIComponent(window.location.href);

      window.open(
        `https://twitter.com/intent/tweet?url=${url}`
      );
    };

  }

}

customElements.define("share-modal", ShareModal);