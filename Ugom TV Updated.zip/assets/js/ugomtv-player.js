/**
 * <ugomtv-player> — Custom Element
 *
 * Attributes:
 *   src        – video URL (required)
 *   poster     – poster image URL (optional)
 *   width      – player width, default "800px"
 *
 * Tracks (subtitle/caption) are added as <track> children, just like a normal <video>:
 *   <ugomtv-player src="…">
 *     <track kind="subtitles" src="en.vtt" srclang="en" label="English">
 *   </ugomtv-player>
 *
 * Dependencies: feather-icons (loaded via CDN if not already present)
 */

(function () {
  /* ── load feather-icons if needed ── */
  function loadFeather() {
    return new Promise((resolve) => {
      if (window.feather) return resolve();
      const s = document.createElement("script");
      s.src = "https://cdn.jsdelivr.net/npm/feather-icons/dist/feather.min.js";
      s.onload = resolve;
      document.head.appendChild(s);
    });
  }

  /* ── HTML template ── */
  const TEMPLATE = document.createElement("template");
  TEMPLATE.innerHTML = /* html */ `
    <style>
      :host {
        display: block;
        --accent-a: #a855f7;
        --accent-b: #3b82f6;
        font-family: 'Segoe UI', system-ui, sans-serif;
      }

      * { margin:0; padding:0; box-sizing:border-box; }

      /* ── PLAYER SHELL ── */
      .ugomtv-player {
        position: relative;
        width: 100%;
        aspect-ratio: 16 / 9;
        background: #000;
        overflow: hidden;
        border-radius: 8px;
      }

      /* ── VIDEO ── */
      video {
        width: 100%;
        height: 100%;
        display: block;
        object-fit: contain;
        background: #000;
      }

      /* ── SPINNER ── */
      .spinner {
        position: absolute;
        top: 50%;
        left: 50%;
        width: 48px;
        height: 48px;
        border: 3px solid transparent;
        border-radius: 50%;
        transform: translate(-50%, -50%);
        display: none;
        z-index: 10;
        pointer-events: none;
      }
      .spinner::before,
      .spinner::after {
        content: '';
        position: absolute;
        inset: -3px;
        border-radius: 50%;
        border: 3px solid transparent;
      }
      .spinner::before {
        border-top-color: rgba(255,255,255,0.25);
        animation: spin 2s linear infinite;
      }
      .spinner::after {
        border-top-color: #fff;
        border-right-color: var(--accent-b);
        animation: spin 0.6s linear infinite;
      }
      @keyframes spin { to { transform: rotate(360deg); } }

      /* ── CONTROLS OVERLAY ── */
      .controls {
        position: absolute;
        bottom: 0;
        left: 0;
        width: 100%;
        padding: 10px;
        background: linear-gradient(transparent, rgba(0,0,0,0.82));
        color: #fff;
        transition: opacity 0.3s ease;
        z-index: 10;
      }

      /* ── PROGRESS ── */
      .progress-container {
        display: flex;
        align-items: center;
        gap: 10px;
        margin-bottom: 8px;
      }

      input[type="range"] {
        flex: 1;
        height: 3px;
        border-radius: 2px;
        background-color: rgba(255,255,255,0.3);
        background-image: linear-gradient(to right, var(--accent-a), var(--accent-b));
        background-repeat: no-repeat;
        background-size: 0% 100%;
        -webkit-appearance: none;
        appearance: none;
        cursor: pointer;
        outline: none;
      }
      input[type="range"]::-webkit-slider-thumb {
        -webkit-appearance: none;
        appearance: none;
        width: 10px;
        height: 10px;
        border-radius: 50%;
        background: #fff;
        cursor: pointer;
      }
      input[type="range"]::-moz-range-thumb {
        width: 10px;
        height: 10px;
        border-radius: 50%;
        background: #fff;
        border: none;
        cursor: pointer;
      }

      .time {
        font-size: 12px;
        white-space: nowrap;
        color: rgba(255,255,255,0.9);
      }

      /* ── BOTTOM ROW ── */
      .bottom-controls {
        display: flex;
        justify-content: space-between;
        align-items: center;
      }
      .left-controls,
      .right-controls {
        display: flex;
        align-items: center;
        gap: 4px;
      }

      /* ── BUTTONS ── */
      button {
        background: transparent;
        border: none;
        color: #fff;
        cursor: pointer;
        padding: 6px;
        display: flex;
        align-items: center;
        justify-content: center;
        border-radius: 6px;
        transition: background 0.15s, opacity 0.15s;
      }
      button:hover { background: rgba(255,255,255,0.12); }
      button svg { width: 20px; height: 20px; stroke-width: 1.5px; }

      /* ── SETTINGS PANELS ── */
      .settings-panel {
        display: none;
        position: absolute;
        bottom: 56px;
        right: 12px;
        width: 260px;
        max-height: calc(100% - 70px);
        overflow-y: auto;
        background: rgba(15,15,15,0.96);
        backdrop-filter: blur(12px);
        border-radius: 10px;
        border: 1px solid rgba(255,255,255,0.08);
        z-index: 20;
      }
      .settings-panel.open { display: block; }

      .settings-header {
        display: flex;
        align-items: center;
        gap: 8px;
        padding: 12px 14px;
        font-size: 14px;
        font-weight: 600;
        color: #000;
        background: #f5f5f5;
        border-bottom: 1px solid #e0e0e0;
      }
      .settings-close-btn { margin-left: auto; padding: 4px; border-radius: 4px; }
      .settings-back-btn  { margin-right: 2px; padding: 4px; border-radius: 4px; }
      .settings-close-btn:hover,
      .settings-back-btn:hover { background: rgba(0,0,0,0.08); }
      .settings-close-btn svg,
      .settings-back-btn svg  { width: 16px; height: 16px; color: #000; }

      .settings-item {
        display: flex;
        align-items: center;
        gap: 12px;
        padding: 12px 14px;
        font-size: 13px;
        color: #111;
        background: #f5f5f5;
        cursor: pointer;
        transition: background 0.15s;
      }
      .settings-item:hover { background: cyan; }
      .settings-item svg { width: 16px; height: 16px; opacity: 0.6; flex-shrink: 0; }

      .settings-value {
        margin-left: auto;
        font-size: 12px;
        color: rgba(0,0,0,0.45);
        margin-right: 4px;
      }

      .speed-option.active,
      .quality-option.active,
      .captions-option.active { color: #000; font-weight: bold; }

      .speed-option.active::after,
      .quality-option.active::after,
      .captions-option.active::after {
        content: '✓';
        margin-left: auto;
        color: #000;
        font-size: 16px;
      }
    </style>

    <div class="ugomtv-player">
      <video></video>

      <div class="spinner"></div>

      <!-- Controls -->
      <div class="controls">
        <div class="progress-container">
          <input type="range" class="progress-bar" value="0" min="0" max="100">
          <span class="time">0:00 / 0:00</span>
        </div>
        <div class="bottom-controls">
          <div class="left-controls">
            <button class="play-pause-btn"><i data-feather="play"></i></button>
            <button class="skip-back-btn"><i data-feather="rotate-ccw"></i></button>
            <button class="skip-forward-btn"><i data-feather="rotate-cw"></i></button>
            <button class="mute-btn"><i data-feather="volume-2"></i></button>
          </div>
          <div class="right-controls">
            <button class="settings-btn"><i data-feather="settings"></i></button>
            <button class="fullscreen-btn"><i data-feather="maximize"></i></button>
          </div>
        </div>
      </div>

      <!-- Settings: main -->
      <div class="settings-panel" id="settingsPanel">
        <div class="settings-header">
          <span>Settings</span>
          <button class="settings-close-btn"><i data-feather="x"></i></button>
        </div>
        <div class="settings-item" id="speedItem">
          <i data-feather="zap"></i><span>Speed</span>
          <span class="settings-value" id="speedLabel">1x · Normal</span>
          <i data-feather="chevron-right"></i>
        </div>
        <div class="settings-item" id="qualityItem">
          <i data-feather="sliders"></i><span>Quality</span>
          <span class="settings-value" id="qualityLabel">—</span>
          <i data-feather="chevron-right"></i>
        </div>
        <div class="settings-item" id="captionsItem" style="display:none">
          <i data-feather="message-square"></i><span>Captions</span>
          <span class="settings-value" id="captionsLabel">Off</span>
          <i data-feather="chevron-right"></i>
        </div>
      </div>

      <!-- Settings: speed -->
      <div class="settings-panel" id="speedPanel">
        <div class="settings-header">
          <button class="settings-back-btn"><i data-feather="chevron-left"></i></button>
          <span>Speed</span>
        </div>
        <div class="settings-item speed-option" data-speed="0.5">0.5x</div>
        <div class="settings-item speed-option" data-speed="0.75">0.75x</div>
        <div class="settings-item speed-option active" data-speed="1">1x · Normal</div>
        <div class="settings-item speed-option" data-speed="1.25">1.25x</div>
        <div class="settings-item speed-option" data-speed="1.5">1.5x</div>
        <div class="settings-item speed-option" data-speed="2">2x</div>
      </div>

      <!-- Settings: quality -->
      <div class="settings-panel" id="qualityPanel">
        <div class="settings-header">
          <button class="settings-back-btn"><i data-feather="chevron-left"></i></button>
          <span>Quality</span>
        </div>
      </div>

      <!-- Settings: captions -->
      <div class="settings-panel" id="captionsPanel">
        <div class="settings-header">
          <button class="settings-back-btn"><i data-feather="chevron-left"></i></button>
          <span>Captions</span>
        </div>
      </div>
    </div>
  `;

  /* ─────────────────────────────────────────── */
  class UgomTVPlayer extends HTMLElement {
    constructor() {
      super();
      this._shadow = this.attachShadow({ mode: "open" });
      this._shadow.appendChild(TEMPLATE.content.cloneNode(true));

      /* internal state */
      this._controlsVisible = true;
      this._hideTimeout = null;
      this._isScrubbing = false;
      this._toggleLock = false;
    }

    /* ── observed attributes ── */
    static get observedAttributes() {
      return ["src", "poster", "width"];
    }

    attributeChangedCallback(name, _old, val) {
      const video = this._shadow.querySelector("video");
      if (!video) return;
      if (name === "src")    { video.src = val; this._buildQualityOptions(); }
      if (name === "poster") { video.poster = val; }
      if (name === "width")  {
        this._shadow.querySelector(".ugomtv-player").style.width = val;
      }
    }

    connectedCallback() {
      loadFeather().then(() => this._init());
    }

    disconnectedCallback() {
      clearTimeout(this._hideTimeout);
    }

    /* ── INIT ── */
    _init() {
      const root = this._shadow;

      /* refs */
      this._video        = root.querySelector("video");
      this._controls     = root.querySelector(".controls");
      this._playPauseBtn = root.querySelector(".play-pause-btn");
      this._muteBtn      = root.querySelector(".mute-btn");
      this._fullscreenBtn= root.querySelector(".fullscreen-btn");
      this._progressBar  = root.querySelector(".progress-bar");
      this._timeDisplay  = root.querySelector(".time");
      this._spinner      = root.querySelector(".spinner");
      this._skipBackBtn  = root.querySelector(".skip-back-btn");
      this._skipFwdBtn   = root.querySelector(".skip-forward-btn");
      this._settingsBtn  = root.querySelector(".settings-btn");
      this._settingsPanel= root.getElementById("settingsPanel");
      this._speedPanel   = root.getElementById("speedPanel");
      this._qualityPanel = root.getElementById("qualityPanel");
      this._captionsPanel= root.getElementById("captionsPanel");

      const video = this._video;

      /* ── transfer src / poster from attributes ── */
      if (this.hasAttribute("src"))    video.src    = this.getAttribute("src");
      if (this.hasAttribute("poster")) video.poster = this.getAttribute("poster");
      if (this.hasAttribute("width"))  {
        root.querySelector(".ugomtv-player").style.width = this.getAttribute("width");
      }

      /* ── transfer <track> children into shadow <video> ── */
      Array.from(this.querySelectorAll("track")).forEach((t) => {
        const clone = t.cloneNode(true);
        video.appendChild(clone);
      });

      /* ── bind all events ── */
      this._bindPlayback();
      this._bindProgress();
      this._bindSpinner();
      this._bindControlsVisibility();
      this._bindSettings();

      /* ── feather icons inside shadow DOM ── */
      this._replaceIcons();

      /* ── initial build ── */
      this._buildQualityOptions();
      this._buildCaptionsOptions();
      video.addEventListener("loadedmetadata", () => this._buildCaptionsOptions());
      video.addEventListener("emptied",        () => this._buildQualityOptions());
    }

    /* ── FEATHER inside shadow DOM ── */
    _replaceIcons() {
      this._shadow.querySelectorAll("[data-feather]").forEach((el) => {
        const name = el.getAttribute("data-feather");
        const svg  = window.feather.icons[name];
        if (!svg) return;
        el.outerHTML = svg.toSvg({ "stroke-width": 1.5 });
      });
    }

    _refreshIcons() {
      /* re-run after dynamic innerHTML changes */
      this._replaceIcons();
    }

    /* ── PLAYBACK ── */
    _bindPlayback() {
      const video = this._video;

      this._playPauseBtn.addEventListener("click", () => {
        if (video.paused) { video.play(); } else { video.pause(); }
      });

      this._muteBtn.addEventListener("click", () => {
        video.muted = !video.muted;
        this._muteBtn.innerHTML = video.muted
          ? window.feather.icons["volume-x"].toSvg({ "stroke-width": 1.5 })
          : window.feather.icons["volume-2"].toSvg({ "stroke-width": 1.5 });
      });

      this._fullscreenBtn.addEventListener("click", () => {
        const shell = this._shadow.querySelector(".ugomtv-player");
        if (!document.fullscreenElement) shell.requestFullscreen();
        else document.exitFullscreen();
      });

      this._skipBackBtn.addEventListener("click", () => { video.currentTime -= 10; });
      this._skipFwdBtn.addEventListener("click",  () => { video.currentTime += 10; });

      video.addEventListener("play",  () => this._setPauseIcon());
      video.addEventListener("pause", () => this._setPlayIcon());
      video.addEventListener("ended", () => {
        this._setPlayIcon();
        this._progressBar.value = 0;
        this._progressBar.style.backgroundSize = "0% 100%";
        this._timeDisplay.textContent = `0:00 / ${this._fmt(video.duration)}`;
        this._showControls();
        video.currentTime = 0;
      });
      video.addEventListener("loadedmetadata", () => {
        this._timeDisplay.textContent = `0:00 / ${this._fmt(video.duration)}`;
      });
    }

    _setPlayIcon() {
      this._playPauseBtn.innerHTML =
        window.feather.icons["play"].toSvg({ "stroke-width": 1.5 });
    }
    _setPauseIcon() {
      this._playPauseBtn.innerHTML =
        window.feather.icons["pause"].toSvg({ "stroke-width": 1.5 });
    }

    /* ── PROGRESS ── */
    _bindProgress() {
      const video = this._video;
      const bar   = this._progressBar;

      video.addEventListener("timeupdate", () => {
        if (!video.duration) return;
        const pct = (video.currentTime / video.duration) * 100;
        this._timeDisplay.textContent =
          `${this._fmt(video.currentTime)} / ${this._fmt(video.duration)}`;
        if (!this._isScrubbing) {
          bar.value = pct;
          bar.style.backgroundSize = `${pct}% 100%`;
        }
      });

      bar.addEventListener("pointerdown", () => { this._isScrubbing = true; });
      bar.addEventListener("input", () => {
        const t = (bar.value / 100) * video.duration;
        video.currentTime = t;
        bar.style.backgroundSize = `${bar.value}% 100%`;
      });

      const endScrub = () => {
        this._isScrubbing = false;
        const pct = (video.currentTime / video.duration) * 100;
        bar.value = pct;
        bar.style.backgroundSize = `${pct}% 100%`;
      };
      bar.addEventListener("pointerup",     endScrub);
      bar.addEventListener("pointercancel", endScrub);
      video.addEventListener("seeked",      endScrub);
    }

    /* ── SPINNER ── */
    _bindSpinner() {
      const v = this._video;
      const s = this._spinner;
      v.addEventListener("waiting",  () => { s.style.display = "block"; });
      v.addEventListener("seeking",  () => { s.style.display = "block"; });
      v.addEventListener("playing",  () => { s.style.display = "none";  });
      v.addEventListener("canplay",  () => { s.style.display = "none";  });
    }

    /* ── CONTROLS VISIBILITY ── */
    _bindControlsVisibility() {
      const shell = this._shadow.querySelector(".ugomtv-player");

      shell.addEventListener("pointermove", () => {
        if (!this._isScrubbing) this._showControls();
      });

      shell.addEventListener("pointerdown", (e) => {
        const isControl = e.target.closest("button") || e.target.closest("input");
        const isPanel   = e.target.closest(".settings-panel");
        if (isControl || isPanel) return;

        this._toggleLock = true;
        this._controlsVisible ? this._hideControls() : this._showControls();
        setTimeout(() => { this._toggleLock = false; }, 200);
      });

      this._video.addEventListener("play", () => {
        this._setPauseIcon();
        this._resetHideTimer();
      });
      this._video.addEventListener("pause", () => this._setPlayIcon());
    }

    _showControls() {
      this._controls.style.opacity = "1";
      this._controls.style.pointerEvents = "auto";
      this._controlsVisible = true;
      this._resetHideTimer();
    }
    _hideControls() {
      this._controls.style.opacity = "0";
      this._controls.style.pointerEvents = "none";
      this._controlsVisible = false;
    }
    _resetHideTimer() {
      clearTimeout(this._hideTimeout);
      this._hideTimeout = setTimeout(() => {
        if (!this._video.paused && !this._isScrubbing) this._hideControls();
      }, 3000);
    }

    /* ── SETTINGS ── */
    _bindSettings() {
      const root = this._shadow;

      const closeAll = () => {
        [this._settingsPanel, this._speedPanel,
         this._qualityPanel,  this._captionsPanel]
          .forEach(p => p.classList.remove("open"));
      };
      this._closeAllPanels = closeAll;

      this._settingsBtn.addEventListener("click", (e) => {
        e.stopPropagation();
        const was = this._settingsPanel.classList.contains("open");
        closeAll();
        if (!was) this._settingsPanel.classList.add("open");
      });

      this._settingsPanel.querySelector(".settings-close-btn")
        .addEventListener("click", closeAll);

      root.getElementById("speedItem").addEventListener("click", () => {
        this._settingsPanel.classList.remove("open");
        this._speedPanel.classList.add("open");
      });
      root.getElementById("qualityItem").addEventListener("click", () => {
        this._settingsPanel.classList.remove("open");
        this._qualityPanel.classList.add("open");
      });
      root.getElementById("captionsItem").addEventListener("click", () => {
        this._settingsPanel.classList.remove("open");
        this._captionsPanel.classList.add("open");
      });

      root.querySelectorAll(".settings-back-btn").forEach(btn => {
        btn.addEventListener("click", () => {
          closeAll();
          this._settingsPanel.classList.add("open");
        });
      });

      root.querySelectorAll(".speed-option").forEach(opt => {
        opt.addEventListener("click", () => {
          this._video.playbackRate = parseFloat(opt.dataset.speed);
          root.querySelectorAll(".speed-option").forEach(o => o.classList.remove("active"));
          opt.classList.add("active");
          root.getElementById("speedLabel").textContent = opt.textContent;
          closeAll();
        });
      });

      /* close panels on outside click */
      this._shadow.querySelector(".ugomtv-player").addEventListener("pointerdown", (e) => {
        if (!e.target.closest(".settings-panel") && !e.target.closest(".settings-btn")) {
          closeAll();
        }
      });
    }

    /* ── QUALITY OPTIONS ── */
    _buildQualityOptions() {
      const root    = this._shadow;
      const video   = this._video;
      const panel   = this._qualityPanel;
      const label   = root.getElementById("qualityLabel");
      if (!panel || !video.src) return;

      panel.querySelectorAll(".quality-option").forEach(o => o.remove());

      const currentSrc = video.src;
      const base = currentSrc.replace(/_r1080p\.mp4|_r720p\.mp4|_r480p\.mp4/, "");
      const qualities = [
        { key: "r1080p", label: "1080p" },
        { key: "r720p",  label: "720p"  },
        { key: "r480p",  label: "480p"  },
      ];

      qualities.forEach(({ key, label: qLabel }) => {
        const src = `${base}_${key}.mp4`;
        const div = document.createElement("div");
        div.className = "settings-item quality-option";
        div.dataset.src     = src;
        div.dataset.quality = qLabel;
        div.textContent     = qLabel;

        if (currentSrc.includes(`_${key}`)) {
          div.classList.add("active");
          if (label) label.textContent = qLabel;
        }

        div.addEventListener("click", () => {
          const ct         = video.currentTime;
          const wasPlaying = !video.paused;
          const activeIdx  = Array.from(video.textTracks)
            .findIndex(t => t.mode === "showing");

          video.src = src;
          video.currentTime = ct;

          video.addEventListener("loadedmetadata", () => {
            if (activeIdx >= 0 && video.textTracks[activeIdx]) {
              video.textTracks[activeIdx].mode = "showing";
            }
          }, { once: true });

          if (wasPlaying) video.play();
          panel.querySelectorAll(".quality-option").forEach(o => o.classList.remove("active"));
          div.classList.add("active");
          if (label) label.textContent = qLabel;
          this._closeAllPanels();
        });

        panel.appendChild(div);
      });
    }

    /* ── CAPTIONS OPTIONS ── */
    _buildCaptionsOptions() {
      const root    = this._shadow;
      const video   = this._video;
      const panel   = this._captionsPanel;
      const item    = root.getElementById("captionsItem");
      const lbl     = root.getElementById("captionsLabel");
      if (!panel) return;

      panel.querySelectorAll(".captions-option").forEach(o => o.remove());

      const tracks = Array.from(video.textTracks);
      if (tracks.length === 0) {
        if (item) item.style.display = "none";
        return;
      }
      if (item) item.style.display = "flex";

      /* Off */
      const offDiv = document.createElement("div");
      offDiv.className = "settings-item captions-option active";
      offDiv.textContent = "Off";
      offDiv.addEventListener("click", () => {
        Array.from(video.textTracks).forEach(t => (t.mode = "hidden"));
        panel.querySelectorAll(".captions-option").forEach(o => o.classList.remove("active"));
        offDiv.classList.add("active");
        if (lbl) lbl.textContent = "Off";
        this._closeAllPanels();
      });
      panel.appendChild(offDiv);

      tracks.forEach((track, i) => {
        const div = document.createElement("div");
        div.className = "settings-item captions-option";
        div.textContent = track.label || track.language || `Track ${i + 1}`;

        div.addEventListener("click", () => {
          Array.from(video.textTracks).forEach(t => (t.mode = "hidden"));
          track.mode = "showing";
          panel.querySelectorAll(".captions-option").forEach(o => o.classList.remove("active"));
          div.classList.add("active");
          if (lbl) lbl.textContent = div.textContent;
          this._closeAllPanels();
        });

        panel.appendChild(div);
      });
    }

    /* ── UTILS ── */
    _fmt(t) {
      const m = Math.floor(t / 60);
      const s = Math.floor(t % 60);
      return `${m}:${s < 10 ? "0" : ""}${s}`;
    }
  }

  /* ── register ── */
  if (!customElements.get("ugomtv-player")) {
    customElements.define("ugomtv-player", UgomTVPlayer);
  }
})();
