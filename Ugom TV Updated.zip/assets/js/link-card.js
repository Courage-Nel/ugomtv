class LinkCard extends HTMLElement {
  connectedCallback() {

    const href = this.getAttribute("href") || "#";
    const image = this.getAttribute("image") || "";
    const title = this.getAttribute("title") || "";

    this.innerHTML = `
      <div class="links-container">
        <a href="${href}">
          <img src="${image}" alt="${title}">
          <span>${title}</span>
        </a>
      </div>
    `;
  }
}

customElements.define("link-card", LinkCard);

