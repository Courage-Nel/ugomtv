class SearchOverlay extends HTMLElement {
  constructor() {
    super();
    this.attachShadow({ mode: "open" });

    this.shadowRoot.innerHTML = `
      <style>
        #searchOverlay {
          position: fixed;
          top: 0;
          left: 0;
          width: 100vw;
          height: 100vh;
          background: rgba(0, 0, 0, 0.3);
          backdrop-filter: blur(10px);

          transform: translateX(100%);
          opacity: 0;
          pointer-events: none;

          transition: 0.3s linear;
          z-index: 1002;
        }

        #searchOverlay.active {
          transform: translateX(0);
          opacity: 1;
          pointer-events: auto;
        }

        form {
          display: flex;
          align-items: center;
          margin-top: 20px;
          margin-left: 5px;
        }

        .search-input {
          width: 250px;
          height: 40px;
          border-radius: 10px 0 0 10px;
          padding: 10px;
          border: 0.5px solid black;
          font-size: 16px;
          outline: none;
        }

        .search-input:focus {
          border: 0.5px solid blue;
        }

        .searchbtn {
          width: 40px;
          height: 40px;
          border-radius: 0 10px 10px 0;
          background: blue;
          color: white;
          border: none;
          cursor: pointer;
        }

        .close-btn {
          background: transparent;
          color: white;
          height: 40px;
          width: 40px;
          border: none;
          margin-top: 20px;
          cursor: pointer;
        }

        #results {
          margin: 10px;
          color: white;
        }

        .result {
          padding: 10px 0;
          border-bottom: 1px solid #ccc;
        }

        .result a {
          text-decoration: none;
          color: blue;
          font-size: 20px;
          display: block;
          margin-bottom: 5px;
        }

        .result p {
          margin: 0;
          font-size: 16px;
        }

        mark {
          background: yellow;
          color: black;
        }
      </style>

      <div id="searchOverlay">
        <button class="close-btn" id="closeSearch">✕</button>

        <form class="search-form">
          <input type="search" class="search-input" placeholder="Type to search...">
          <button type="submit" class="searchbtn">
            <i data-feather="search"></i>
          </button>
        </form>

        <div id="results"></div>
      </div>
    `;
  }

  connectedCallback() {
    this.overlay = this.shadowRoot.getElementById("searchOverlay");
    this.closeBtn = this.shadowRoot.getElementById("closeSearch");
    this.form = this.shadowRoot.querySelector(".search-form");
    this.input = this.shadowRoot.querySelector(".search-input");
    this.resultsContainer = this.shadowRoot.getElementById("results");

    this.pages = [];

    // external trigger button
    document.querySelector(".search-btn")
      ?.addEventListener("click", () => this.open());

    // close button
    this.closeBtn.addEventListener("click", () => this.close());

    // click outside closes
    this.overlay.addEventListener("click", (e) => {
      if (e.target === this.overlay) this.close();
    });

    // live search
    this.input.addEventListener("input", () => {
      this.showResults(this.input.value);
    });

    // submit search
    this.form.addEventListener("submit", (e) => {
      e.preventDefault();
      this.showResults(this.input.value);
    });

    // ✅ FIXED FETCH PATH
    fetch("assets/data/search.json")
      .then(res => {
        if (!res.ok) throw new Error("Failed to load JSON");
        return res.json();
      })
      .then(data => {
        this.pages = Array.isArray(data) ? data : [];
        console.log("Search index loaded:", this.pages);
      })
      .catch(err => {
        console.error("Search JSON error:", err);
        this.resultsContainer.innerHTML =
          "<p style='color:red'>Search data failed to load</p>";
      });

    if (window.feather) feather.replace();
  }

  showResults(query) {
    query = query.trim().toLowerCase();

    if (!query) {
      this.resultsContainer.innerHTML = "<p>Please enter a search term.</p>";
      return;
    }

    const results = this.pages.filter(page => {
      const title = (page.title || "").toLowerCase();
      const content = (page.content || "").toLowerCase();
      const keywords = (page.keywords || "").toLowerCase();

      return (
        title.includes(query) ||
        content.includes(query) ||
        keywords.includes(query)
      );
    });

    const highlight = (text) => {
      if (!text) return "";
      const regex = new RegExp(`(${query})`, "gi");
      return text.replace(regex, "<mark>$1</mark>");
    };

    this.resultsContainer.innerHTML = results.length
      ? results.map(r => `
          <div class="result">
            <a href="${r.url || "#"}">${highlight(r.title)}</a>
            <p>${highlight(r.content)}</p>
          </div>
        `).join("")
      : "<p>No results found. Try another keyword.</p>";
  }

  open() {
    this.overlay.classList.add("active");
    document.body.style.overflow = "hidden";
    setTimeout(() => this.input.focus(), 100);
  }

  close() {
    this.overlay.classList.remove("active");
    document.body.style.overflow = "";
  }
}

customElements.define("search-overlay", SearchOverlay);