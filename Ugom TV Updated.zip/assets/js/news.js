// Create a custom HTML element called <news-list>
class NewsList extends HTMLElement {

  // Runs when the element is created
  constructor() {
    super();

    // Create Shadow DOM
    this.attachShadow({ mode: "open" });
  }

  // Runs when the element is added to the page
  connectedCallback() {

    // Get the image attribute value
    const image = this.getAttribute("image") || "";

    // Get the title attribute value
    const title = this.getAttribute("title") || "";

    // Get the page link
    const link = this.getAttribute("link") || "#";

    // Insert the component HTML
    this.shadowRoot.innerHTML = `
      <style>
        * {
          box-sizing: border-box;
        }

        /* Remove default link style */
        a {
          text-decoration: none;
          color: inherit;
        }

        /* Modern news card */
        .item {
          background: #fff;
          border-radius: 18px;
          overflow: hidden;
          box-shadow: 0 4px 20px rgba(0,0,0,0.08);
          transition: transform 0.2s ease;
          cursor: pointer;
        }

        /* Hover effect */
        .item:hover {
          transform: translateY(-4px);
        }

        /* Full image on top */
        img {
          width: 100%;
          height: 200px;
          object-fit: cover;
          display: block;
        }

        /* Content area */
        .content {
          padding: 16px;
        }

        /* News title */
        .title {
          font-size: 18px;
          font-weight: 500;
          color: blue;
          line-height: 1.5;
        }
      </style>

      <!-- Clickable news card -->
      <a href="${link}">
        <div class="item">

          <!-- News image -->
          <img src="${image}" alt="${title}">

          <!-- News content -->
          <div class="content">

            <!-- News title -->
            <div class="title">
              ${title}
            </div>

          </div>
        </div>
      </a>
    `;
  }
}

// Register the custom element
customElements.define("news-list", NewsList);