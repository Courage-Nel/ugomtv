// =========================
// FIREBASE INIT
// =========================

const firebaseConfig = {
  apiKey: "AIzaSyBLjB0Vrwd0WIx28AkXLpH3eIbPStJW3IY",
  authDomain: "ugomtv.firebaseapp.com",
  projectId: "ugomtv",
  storageBucket: "ugomtv.firebasestorage.app",
  messagingSenderId: "874120978546",
  appId: "1:874120978546:web:38466609ffed296adfa2eb",
  measurementId: "G-0FHVSGSR19"
};

firebase.initializeApp(firebaseConfig);

const auth = firebase.auth();
const db = firebase.firestore();


// =========================
// TOAST SYSTEM
// =========================

(function () {
  let container = document.getElementById("toast-container");

  if (!container) {
    container = document.createElement("div");
    container.id = "toast-container";
    document.body.appendChild(container);
  }
})();

function showToast(message, type = "info", duration = 3000) {
  const container = document.getElementById("toast-container");

  const toast = document.createElement("div");
  toast.className = `toast toast-${type}`;
  toast.textContent = message;

  container.appendChild(toast);

  setTimeout(() => {
    toast.classList.add("hide");
    setTimeout(() => toast.remove(), 300);
  }, duration);
}


// =========================
// PASSWORD TOGGLE
// =========================

window.togglePassword = function (id) {
  const input = document.getElementById(id);
  if (!input) return;
  input.type = input.type === "password" ? "text" : "password";
};


// =========================
// GLOBAL AUTH + HOMEPAGE AVATAR
// =========================

document.addEventListener("DOMContentLoaded", () => {

  const homeAvatar = document.getElementById("homeAvatar");
  const avatarLink = document.getElementById("avatarLink");

  auth.onAuthStateChanged(async (user) => {

    // NOT LOGGED IN
    if (!user) {

      if (homeAvatar) {
        homeAvatar.src = "https://via.placeholder.com/40";
      }

      if (avatarLink) {
        avatarLink.onclick = () => {
          window.location.href = "/auth/login.html";
        };
      }

      return;
    }

    // LOGGED IN
    try {

      const doc = await db.collection("users").doc(user.uid).get();
      const data = doc.exists ? doc.data() : null;

      if (homeAvatar) {
        homeAvatar.src =
          data?.profilePic || "https://via.placeholder.com/40";
      }

      if (avatarLink) {
        avatarLink.onclick = () => {
          window.location.href = "/profile/index.html";
        };
      }

    } catch (err) {
      console.error(err);
    }

  });

});


// =========================
// SIGN UP
// =========================

const signupForm = document.getElementById("signupForm");

if (signupForm) {
  signupForm.addEventListener("submit", async (e) => {

    e.preventDefault();

    const firstName = document.getElementById("firstName").value.trim();
    const surname = document.getElementById("surname").value.trim();
    const phone = document.getElementById("phone").value.trim();
    const email = document.getElementById("email").value.trim();
    const password = document.getElementById("password").value;
    const confirmPassword = document.getElementById("confirmPassword").value;

    if (password !== confirmPassword) {
      showToast("Passwords do not match", "error");
      return;
    }

    try {

      const userCredential =
        await auth.createUserWithEmailAndPassword(email, password);

      const user = userCredential.user;

      await db.collection("users").doc(user.uid).set({
        firstName,
        surname,
        phone,
        email,
        profilePic: "",
        dob: "",
        gender: "",
        createdAt: firebase.firestore.FieldValue.serverTimestamp()
      });

      showToast("Account created successfully", "success");

      window.location.href = "/profile/index.html";

    } catch (err) {
      showToast(err.message, "error");
    }

  });
}


// =========================
// LOGIN
// =========================

const loginForm = document.getElementById("loginForm");

if (loginForm) {
  loginForm.addEventListener("submit", async (e) => {

    e.preventDefault();

    const email = document.getElementById("loginEmail").value.trim();
    const password = document.getElementById("loginPassword").value;

    try {

      await auth.signInWithEmailAndPassword(email, password);

      showToast("Login successful", "success");

      window.location.href = "/profile/index.html";

    } catch (err) {
      showToast(err.message, "error");
    }

  });
}


// =========================
// PROFILE PAGE
// =========================

document.addEventListener("DOMContentLoaded", () => {

  const userName = document.getElementById("userName");
  const profilePic = document.getElementById("profilePic");
  const dobText = document.getElementById("dobText");
  const genderText = document.getElementById("genderText");

  const editBtn = document.getElementById("editBtn");
  const logoutBtn = document.getElementById("logoutBtn");

  if (!userName) return;

  auth.onAuthStateChanged(async (user) => {

    if (!user) {
      window.location.href = "/auth/login.html";
      return;
    }

    try {

      const doc = await db.collection("users").doc(user.uid).get();

      if (!doc.exists) return;

      const data = doc.data();

      userName.textContent =
        `${data.firstName || ""} ${data.surname || ""}`;

      profilePic.src =
        data.profilePic || "https://via.placeholder.com/150";

      if (dobText)
        dobText.textContent =
          data.dob ? `DOB: ${data.dob}` : "DOB: Not set";

      if (genderText)
        genderText.textContent =
          data.gender ? `Gender: ${data.gender}` : "Gender: Not set";

    } catch (err) {
      showToast("Failed to load profile", "error");
    }

  });

  if (editBtn) {
    editBtn.onclick = () => {
      window.location.href = "/profile/edit-profile.html";
    };
  }

  if (logoutBtn) {
    logoutBtn.onclick = async () => {
      await auth.signOut();
      showToast("Logged out", "info");
      window.location.href = "/auth/login.html";
    };
  }

});


// =========================
// EDIT PROFILE PAGE
// =========================

document.addEventListener("DOMContentLoaded", () => {

  const uploadPic = document.getElementById("uploadPic");
  const previewPic = document.getElementById("previewPic");
  const dobInput = document.getElementById("dob");
  const genderInput = document.getElementById("gender");
  const saveBtn = document.getElementById("saveBtn");

  if (!uploadPic || !saveBtn) return;

  let imageData = "";

  uploadPic.addEventListener("change", (e) => {

    const file = e.target.files[0];
    if (!file) return;

    const reader = new FileReader();

    reader.onload = (ev) => {
      imageData = ev.target.result;
      if (previewPic) previewPic.src = imageData;
    };

    reader.readAsDataURL(file);

  });

  saveBtn.addEventListener("click", async () => {

    const user = auth.currentUser;

    if (!user) {
      showToast("Not logged in", "error");
      return;
    }

    try {

      const updateData = {
        dob: dobInput?.value || "",
        gender: genderInput?.value || ""
      };

      if (imageData) {
        updateData.profilePic = imageData;
      }

      await db.collection("users")
        .doc(user.uid)
        .set(updateData, { merge: true });

      showToast("Profile updated", "success");

      window.location.href = "/profile/index.html";

    } catch (err) {
      showToast(err.message, "error");
    }

  });

});