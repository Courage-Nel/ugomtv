// Toggle menu for mobile navigation
function toggleMenu() {
    const menu = document.getElementById("menu");
    if (menu) menu.classList.toggle("open");
}

function closeMenu() {
    const menu = document.getElementById("menu");
    if (menu) menu.classList.remove("open");
}

// Go back in browser history
function goBack() {
    window.history.back();
}

// Update clock every second
function updateClock() {
    const now = new Date();
    let hours = now.getHours();
    let minutes = now.getMinutes();
    let seconds = now.getSeconds();

    hours = hours < 10 ? "0" + hours : hours;
    minutes = minutes < 10 ? "0" + minutes : minutes;
    seconds = seconds < 10 ? "0" + seconds : seconds;

    const timeString = `${hours}:${minutes}:${seconds}`;
    const clock = document.getElementById("clock");
    if (clock) clock.innerHTML = timeString;
}
setInterval(updateClock, 1000);
updateClock();

// Run after DOM is fully loaded
document.addEventListener("DOMContentLoaded", () => {
    // Update footer year
    const currentYear = new Date().getFullYear();
    const yearSpan = document.getElementById("year");
    if (yearSpan) yearSpan.textContent = currentYear;

    // Search overlay logic
    const openSearch = document.getElementById("openSearch");
    const closeSearch = document.getElementById("closeSearch");
    const searchOverlay = document.getElementById("searchOverlay");

    if (openSearch && closeSearch && searchOverlay) {
        openSearch.addEventListener("click", () => {
            searchOverlay.classList.add("active");
        });

        closeSearch.addEventListener("click", () => {
            searchOverlay.classList.remove("active");
        });
    }
});
